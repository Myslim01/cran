<?php

namespace Model;


use Module\Database;

class Jackpot
{

    public static function table(){
        return Database::table(MYSQL_PREFIX.'jackpots');
    }

    public static function insert($data){
        return self::table()->insert($data);
    }

    public static function get(){
        return self::table()->select('*')->orderBy('j_id', 'DESC')->get();
    }

}