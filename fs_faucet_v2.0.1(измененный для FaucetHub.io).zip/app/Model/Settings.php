<?php

/* Bitcoin faucet
 * http://faucetsystem.com/
 * Copyright (c) 2017 FaucetSystem.com
 *
 * Email: faucetsystem@gmail.com
 * ToxID: 77755759350B68121FED9377DFF1D4030793DBA9A23EED849E6369CF880E277297915137F7AB
 */

namespace Model;

use Module\Database;

//Key-value rules
class Settings {

    public static function table(){
        return Database::table(MYSQL_PREFIX.'settings');
    }

    public static function get($key=null){
        if(is_null($key)){
            return self::table()->select('*')->setFetchMode(\PDO::FETCH_COLUMN|\PDO::FETCH_UNIQUE)->get();
        }
        return self::table()->select('setting_value')->where('setting_key', '=', $key)->get()[0]->setting_value;

    }

    public static function update($key, $value=null){
        if(is_null($value)){
            foreach ($key as $k=>$v) self::update($k, $v);
        }else{
            return self::table()->where('setting_key', '=', $key)->update(['setting_value'=>$value]);
        }
    }

    public static function jackpot($amount){
        self::table()->where('setting_key', '=', 'jackpot_amount')->update(['setting_value'=>Database::raw('`setting_value` + '.$amount)]);
    }
}