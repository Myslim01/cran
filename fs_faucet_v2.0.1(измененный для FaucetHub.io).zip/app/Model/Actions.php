<?php

/* Bitcoin faucet
 * http://faucetsystem.com/
 * Copyright (c) 2017 FaucetSystem.com
 *
 * Email: faucetsystem@gmail.com
 * ToxID: 77755759350B68121FED9377DFF1D4030793DBA9A23EED849E6369CF880E277297915137F7AB
 */

namespace Model;

use Module\Database;
use Module\Ip;

class Actions {

    public static function table(){
        return Database::table(MYSQL_PREFIX.'actions');
    }

    public static function insert($data){
        $data = array_merge($data, ['a_ip'=>sprintf('%u', ip2long(Ip::get())), 'a_time'=>time(), 'a_useragent'=>$_SERVER['HTTP_USER_AGENT']]);
        self::table()->insert($data);
    }

    public static function count(){
        return self::table()->select(Database::raw('count(a_id) as count'))->get()[0]->count;
    }

    public static function getPerPage($page, $count){
        return self::table()->select("*")->orderBy('a_id', 'DESC')->limit($count)->offset(($page-1)*$count)->get();
    }
}