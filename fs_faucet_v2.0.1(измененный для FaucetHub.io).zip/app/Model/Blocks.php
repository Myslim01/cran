<?php

/* Bitcoin faucet
 * http://faucetsystem.com/
 * Copyright (c) 2017 FaucetSystem.com
 *
 * Email: faucetsystem@gmail.com
 * ToxID: 77755759350B68121FED9377DFF1D4030793DBA9A23EED849E6369CF880E277297915137F7AB
 */

namespace Model;

use Module\Database;

class Blocks {

    public static function table(){
        return Database::table(MYSQL_PREFIX.'blocks');
    }

    public static function getByPage($block_page){
        return self::table()->select('*')->where('block_page','=', $block_page)->get();
    }

    public static function get(){
        return self::table()->select('*')->get();
    }

    public static function updateByPage($block_page, $data){
        foreach ($data as $k=>$v){
            self::table()->select('*')->where('block_page','=', $block_page)->where('block_name', '=', $k)->update(['block_content'=>$v]);
        }
    }

}