<?php

/* Bitcoin faucet
 * http://faucetsystem.com/
 * Copyright (c) 2017 FaucetSystem.com
 *
 * Email: faucetsystem@gmail.com
 * ToxID: 77755759350B68121FED9377DFF1D4030793DBA9A23EED849E6369CF880E277297915137F7AB
 */

namespace Model;

use Module\Database;

class Bans {

    public static function table(){
        return Database::table(MYSQL_PREFIX.'bans');
    }

    public static function insert($data){
        self::table()->insert($data);
    }

    public static function deleteById($b_id){
        self::table()->where('b_id','=', $b_id)->delete();
    }

    public static function getByData($b_data){
        $return = self::table()->select('*')->where('b_data','=', $b_data)->get();
        return isset($return[0])?$return[0]:null;
    }

    public static function count(){
        return self::table()->select(Database::raw('count(b_id) as count'))->get()[0]->count;
    }

    public static function getPerPage($page, $count){
        return self::table()->select("*")->orderBy('b_id', 'DESC')->limit($count)->offset(($page-1)*$count)->get();
    }
}