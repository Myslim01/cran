<?php

/* Bitcoin faucet
 * http://faucetsystem.com/
 * Copyright (c) 2017 FaucetSystem.com
 *
 * Email: faucetsystem@gmail.com
 * ToxID: 77755759350B68121FED9377DFF1D4030793DBA9A23EED849E6369CF880E277297915137F7AB
 */

namespace Model;

use Module\Database;
use Module\Ip;

class Payments {

    public static function table(){
        return Database::table(MYSQL_PREFIX.'payments');
    }

    public static function insert($data){
        $system = ['p_useragent'=>$_SERVER['HTTP_USER_AGENT'],'p_time'=>time(),'p_ip'=>sprintf('%u', ip2long(Ip::get()))];
        return self::table()->insert(array_merge($data, $system));
    }

    public static function getById($p_id){
        $return  = self::table()->select('*')->where('p_id','=', $p_id)->get();
        return isset($return[0])?$return[0]:null;
    }

    public static function count(){
        return self::table()->select(Database::raw('count(p_id) as count'))->get()[0]->count;

    }

    public static function getPerPage($page, $count){
        return self::table()->select("*")->orderBy('p_id', 'DESC')->limit($count)->offset(($page-1)*$count)->get();
    }

    public static function getRecentWins(){
        return self::table()->select('*')->where('p_referral','=', '0')->orderBy('p_id', 'DESC')->limit(45)->get();
    }

    public static function getByIP($p_ip){
        $p_ip = sprintf('%u', ip2long($p_ip));
        $return = self::table()->select('*')->where('p_ip','=', $p_ip)->orderBy('p_id', 'DESC')->get();
        return isset($return[0])?$return[0]:null;
    }

    public static function getByAddress($p_address){
        $return = self::table()->select('*')->where('p_address','=', $p_address)->orderBy('p_id', 'DESC')->get();
        return isset($return[0])?$return[0]:null;
    }
}