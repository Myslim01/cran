<?php

/* Bitcoin faucet
 * http://faucetsystem.com/
 * Copyright (c) 2017 FaucetSystem.com
 *
 * Email: faucetsystem@gmail.com
 * ToxID: 77755759350B68121FED9377DFF1D4030793DBA9A23EED849E6369CF880E277297915137F7AB
 */

namespace Module;

class Secure {

    public static function getRandomString($length=10){
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    public static function js($string){
        $return = '';
        foreach (str_split($string) as $symbol) {
            switch (rand(0,2)){
                case 0:
                    $return .= $symbol.'"+"';
                    break;
                case 1:
                    $return .= '"+String.fromCharCode('.ord($symbol).')+"';
                    break;
                case 2:
                    $return .= "\x".bin2hex($symbol).'"+"';
                    break;
            }
        }
        return $return;
    }

    public static function is_ssl(){
        if(isset($_SERVER['HTTPS'])){
            if('on' == strtolower($_SERVER['HTTPS']))
                return true;
            if('1' == $_SERVER['HTTPS'])
                return true;
            if(true == $_SERVER['HTTPS'])
                return true;
        }elseif(isset($_SERVER['SERVER_PORT']) && ('443' == $_SERVER['SERVER_PORT'])){
            return true;
        }
        if(isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) == 'https') {
            return true;
        }
        return false;
    }

}