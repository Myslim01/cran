<?php

namespace Module;

use DirectoryIterator;
use GDText\Box;
use GDText\Color;

class Lc {

    public static function getBase64($im){
        ob_start();
        imagejpeg($im, null, 80);
        $image_data = ob_get_contents ();
        ob_end_clean();
        return base64_encode($image_data);
    }

    public static function answer($font){
        $img = imagecreatetruecolor(120, 40);
        $img2 = imagecreatetruecolor(120, 40);
        imagefill($img, 0, 0, imagecolorallocate($img, 255, 255, 255));
        imagefill($img2, 0, 0, imagecolorallocate($img, 255, 255, 255));
        $box = new Box($img);
        $box->setFontSize(rand(35,45));
        $box->setBox(0, 0, 120, 40);
        $box->setFontFace($font);
        $box->setTextAlign('center', 'center');
        $box->draw(Secure::getRandomString(3));

        $rand1 = mt_rand(700000, 1000000) / 15000000;
        $rand2 = mt_rand(700000, 1000000) / 15000000;
        $rand3 = mt_rand(700000, 1000000) / 15000000;
        $rand4 = mt_rand(700000, 1000000) / 15000000;

        $rand5 = mt_rand(0, 3141592) / 1000000;
        $rand6 = mt_rand(0, 3141592) / 1000000;
        $rand7 = mt_rand(0, 3141592) / 1000000;
        $rand8 = mt_rand(0, 3141592) / 1000000;

        $rand9 = mt_rand(400, 500) / 100;
        $rand10 = mt_rand(400, 500) / 100;

        for($x = 0; $x < imagesx($img); $x++){
            for($y = 0; $y < imagesy($img); $y++){
                $sx = $x + ( sin($x * $rand1 + $rand5) + sin($y * $rand3 + $rand6) ) * $rand9;
                $sy = $y + ( sin($x * $rand2 + $rand7) + sin($y * $rand4 + $rand8) ) * $rand10;

                if($sx < 0 || $sy < 0 || $sx >= imagesx($img) - 1 || $sy >= imagesy($img) - 1){
                    $color = 255;
                    $color_x = 255;
                    $color_y = 255;
                    $color_xy = 255;
                }else{
                    $color = (imagecolorat($img, $sx, $sy) >> 16) & 0xFF;
                    $color_x = (imagecolorat($img, $sx + 1, $sy) >> 16) & 0xFF;
                    $color_y = (imagecolorat($img, $sx, $sy + 1) >> 16) & 0xFF;
                    $color_xy = (imagecolorat($img, $sx + 1, $sy + 1) >> 16) & 0xFF;
                }




                if($color == $color_x && $color == $color_y && $color == $color_xy){
                    $newcolor=$color;
                }else{
                    $frsx = $sx - floor($sx);
                    $frsy = $sy - floor($sy);
                    $frsx1 = 1 - $frsx;
                    $frsy1 = 1 - $frsy;

                    $newcolor = floor( $color    * $frsx1 * $frsy1 +
                        $color_x  * $frsx  * $frsy1 +
                        $color_y  * $frsx1 * $frsy  +
                        $color_xy * $frsx  * $frsy );
                }
                imagesetpixel($img2, $x, $y, imagecolorallocate($img2, $newcolor, $newcolor, $newcolor));
            }
        }

        return self::getBase64($img2);

    }

    public static function generate(){

        $answer = '';

        foreach ((new DirectoryIterator(R.'/storage/fonts')) as $fi) {
            if (!$fi->isDir() AND !$fi->isDot()) {
                $fonts[] = $fi->getpathName();
            }
        }

        $im = imagecreatetruecolor(400, 120);
        imagefill($im, 0, 0, imagecolorallocate($im, 255, 255, 255));

        $box = new Box($im);
        $box->setFontFace(R.'/storage/Quikhand.ttf');
        $box->setTextShadow(new Color(0, 0, 0, 90), 1, 1);
        $box->setFontSize(20);
        $box->setBox(0, 10, 400, 20);
        $box->setTextAlign('center', 'top');
        $box->draw("Click on the similar images in the following order:\nImportant: look at the fonts/shapes - not the words");


        $box->setBox(20, 80, 360, 40);
        foreach (['left', 'center', 'right'] as $position){
            $rand = rand(0, count($fonts)-1);
            $box->setFontSize(rand(35,45));
            $box->setFontFace($fonts[$rand]);
            $box->setTextAlign($position, 'bottom');
            $box->draw(Secure::getRandomString(3));
            $code = md5(Secure::getRandomString(10));
            $answers[$code] = self::answer($fonts[$rand]);
            $answer .= $code;
            unset($fonts[$rand]);
            $fonts = array_values($fonts);
        }

        $question = self::getBase64($im);

        for($i=0;$i<1; $i++){
            $rand = rand(0, count($fonts)-1);
            $pseudo[md5(Secure::getRandomString(10))] = self::answer($fonts[$rand]);
            unset($fonts[$rand]);
            $fonts = array_values($fonts);
        }


        $vars = array_merge($answers, $pseudo);
        $keys = array_keys($vars);
        shuffle($keys);
        $vars = array_merge(array_flip($keys), $vars);

        return ['question'=>$question, 'vars'=>$vars, 'answer'=>$answer];
    }

}