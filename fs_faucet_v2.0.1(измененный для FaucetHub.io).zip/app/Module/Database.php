<?php

/* Bitcoin faucet
 * http://faucetsystem.com/
 * Copyright (c) 2017 FaucetSystem.com
 *
 * Email: faucetsystem@gmail.com
 * ToxID: 77755759350B68121FED9377DFF1D4030793DBA9A23EED849E6369CF880E277297915137F7AB
 */

namespace Module;

class Database
{
    private static $_instance;

    public static function __callStatic($method, $values){
        if (!isset(self::$_instance)){
            try{
                self::$_instance = new \Pixie\QueryBuilder\QueryBuilderHandler(new \Pixie\Connection('mysql', [
                    'host'      => MYSQL_SERVER,
                    'database'  => MYSQL_BASE,
                    'username'  => MYSQL_LOGIN,
                    'password'  => MYSQL_PASSWORD,
                    'charset'   => 'utf8',
                    'collation' => 'utf8_unicode_ci',
                ]));
            }catch (\Exception $e) {
                exit("<div style='width: 100%; text-align: center'>".
                         "<span style='color: red'>Can't connect to database server.</span><br>".
                         "Check your <b>".R."/config.php</b> file.<br>Error: ".$e->getMessage().
                     "</div>");
            }
        }
        return call_user_func_array([self::$_instance, $method], $values);
    }
}