<?php

/* Bitcoin faucet
 * http://faucetsystem.com/
 * Copyright (c) 2017 FaucetSystem.com
 *
 * Email: faucetsystem@gmail.com
 * ToxID: 77755759350B68121FED9377DFF1D4030793DBA9A23EED849E6369CF880E277297915137F7AB
 */

namespace Module;

use Model\Settings;

class Render extends \Fenom {
    use \Fenom\StorageTrait;

    public function __construct() {
        parent::__construct(new \Fenom\Provider(R));
        $this->setCompileDir(R.'/tmp');
        $this->setOptions(\Fenom::AUTO_RELOAD | \Fenom::FORCE_INCLUDE);
    }

    function before() {
        $this->settings = Settings::get();
        $this->role = \Session::get('admin')?'admin':'guest';

        if(strpos($this->access, $this->role) === False ){
            exit(header('Location: /guest/login/'));
        }
    }

    function after() {

        $this->assign('settings', $this->settings);
        $this->assign('toastr', \Session::get('toastr'));
        \Session::delete('toastr');
        if($this->settings['os_iframe']) header('X-Frame-Options: SAMEORIGIN');

        if($this->role == 'admin' AND (new \ReflectionClass($this))->getShortName()=='Admin'){
            $this->display('/storage/admin/src/loader.tpl');
        }else{
            $this->display('template/'.$this->settings['system_template'].'/src/loader.tpl');
        }

    }
}