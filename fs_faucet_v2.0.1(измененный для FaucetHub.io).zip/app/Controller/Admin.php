<?php

/* Bitcoin faucet
 * http://faucetsystem.com/
 * Copyright (c) 2017 FaucetSystem.com
 *
 * Email: faucetsystem@gmail.com
 * ToxID: 77755759350B68121FED9377DFF1D4030793DBA9A23EED849E6369CF880E277297915137F7AB
 */

namespace Controller;


use DirectoryIterator;
use Model\Actions;
use Model\Bans;
use Model\Blocks;
use Model\Payments;
use Model\Settings;
use Module\Faucetsystem;
use Module\Render;
use phpFastCache\CacheManager;

class Admin extends Render {

    public $access = 'admin';

    public function getDashboard(){
        $faucetsystem = new Faucetsystem($this->settings['faucetsystem_apikey']);
        $this->assign('fs', ['balance'=>$faucetsystem->getBalance()]);
        $this->assign('page', '/storage/admin/src/page/dashboard.tpl');
    }

    public function postDashboard(){
        if(!isset($_POST['token']) OR $_POST['token'] <> \Session::get('token')) {
            exit(header('Location: /admin/dashboard/'));
        }

        CacheManager::delete('faucetsystem_error');
        CacheManager::delete('faucetsystem');

        Settings::update('faucetsystem_apikey', trim($_POST['faucetsystem_apikey']));
        exit(header('Location: /admin/dashboard/'));
    }

    public function getBase(){

        $templates = [];
        foreach ((new DirectoryIterator(R.DIRECTORY_SEPARATOR.'template')) as $fi) {
            if ($fi->isDir() AND !$fi->isDot()) {
                $templates[] = (string) $fi;
            }
        }

        foreach ((new DirectoryIterator(R.'/storage/bgs')) as $fi) {
            if (!$fi->isDir() AND !$fi->isDot()) {
                $bgs[] = $fi->getFilename();
            }
        }

        $this->assign('bgs', $bgs);
        $this->assign('templates', $templates);
        $this->assign('page', '/storage/admin/src/page/settings_base.tpl');
    }

    public function postBase(){
        if(!isset($_POST['token']) OR $_POST['token'] <> \Session::get('token')) {
            exit(header('Location: /admin/dashboard/'));
        }
        if(isset($_POST['referral_commission'])){
            $_POST['referral_commission'] = ((int) $_POST['referral_commission']>=0)?(int) $_POST['referral_commission']:0;
        }else{
            $_POST['referral_commission'] = 0;
        }

        Settings::update($_POST);

        exit(header('Location: /admin/settings/base/'));
    }

    public function getSecurity(){
        $this->assign('page', '/storage/admin/src/page/settings_security.tpl');
    }

    public function postSecurity(){
        if(!isset($_POST['token']) OR $_POST['token'] <> \Session::get('token')) {
            exit(header('Location: /admin/dashboard/'));
        }

        foreach (['timer_global', 'timer_first', 'timer_second'] as $k){
            $_POST[$k] = ((int) $_POST[$k]>=10)?(int) $_POST[$k]:10;
        }
        Settings::update($_POST);
        exit(header('Location: /admin/settings/security/'));
    }

    public function getMoney(){
        $this->assign('page', '/storage/admin/src/page/settings_money.tpl');
    }

    public function postMoney(){
        if(!isset($_POST['token']) OR $_POST['token'] <> \Session::get('token')) {
            exit(header('Location: /admin/dashboard/'));
        }

        $data = [];
        foreach ($_POST['reward'] as $k=>$v){
            if((int) $v > 0){
                if((float) $_POST['chance'][$k]>=0.01 AND (float) $_POST['chance'][$k]<=100){
                    $data[(int) $v] = (string) sprintf ("%.2f", (float) $_POST['chance'][$k]);
                }
            }
        }
        ksort($data);
        if((string) array_sum($data) == '100'){ //0_0 its a magic
            Settings::update('money_reward', json_encode($data));
        }
        exit(header('Location: /admin/settings/money/'));
    }

    public function getCountry(){
        $countries = [
        'AD'=>'Andorra',
        'AE'=>'United Arab Emirates',
        'AF'=>'Afghanistan',
        'AG'=>'Antigua and Barbuda',
        'AI'=>'Anguilla',
        'AL'=>'Albania',
        'AM'=>'Armenia',
        'AO'=>'Angola',
        'AQ'=>'Antarctica',
        'AR'=>'Argentina',
        'AS'=>'American Samoa',
        'AT'=>'Austria',
        'AU'=>'Australia',
        'AW'=>'Aruba',
        'AX'=>'Aland Islands',
        'AZ'=>'Azerbaijan',
        'BA'=>'Bosnia and Herzegovina',
        'BB'=>'Barbados',
        'BD'=>'Bangladesh',
        'BE'=>'Belgium',
        'BF'=>'Burkina Faso',
        'BG'=>'Bulgaria',
        'BH'=>'Bahrain',
        'BI'=>'Burundi',
        'BJ'=>'Benin',
        'BL'=>'Saint Barthelemy',
        'BM'=>'Bermuda',
        'BN'=>'Brunei Darussalam',
        'BO'=>'Bolivia, Plurinational State of',
        'BQ'=>'Bonaire, Sint Eustatius and Saba',
        'BR'=>'Brazil',
        'BS'=>'Bahamas',
        'BT'=>'Bhutan',
        'BV'=>'Bouvet Island',
        'BW'=>'Botswana',
        'BY'=>'Belarus',
        'BZ'=>'Belize',
        'CA'=>'Canada',
        'CC'=>'Cocos (Keeling) Islands',
        'CD'=>'Congo, the Democratic Republic of the',
        'CF'=>'Central African Republic',
        'CG'=>'Congo',
        'CH'=>'Switzerland',
        'CI'=>"Cote d'Ivoire",
        'CK'=>'Cook Islands',
        'CL'=>'Chile',
        'CM'=>'Cameroon',
        'CN'=>'China',
        'CO'=>'Colombia',
        'CR'=>'Costa Rica',
        'CU'=>'Cuba',
        'CV'=>'Cabo Verde',
        'CW'=>'Curacao',
        'CX'=>'Christmas Island',
        'CY'=>'Cyprus',
        'CZ'=>'Czech Republic',
        'DE'=>'Germany',
        'DJ'=>'Djibouti',
        'DK'=>'Denmark',
        'DM'=>'Dominica',
        'DO'=>'Dominican Republic',
        'DZ'=>'Algeria',
        'EC'=>'Ecuador',
        'EE'=>'Estonia',
        'EG'=>'Egypt',
        'EH'=>'Western Sahara',
        'ER'=>'Eritrea',
        'ES'=>'Spain',
        'ET'=>'Ethiopia',
        'FI'=>'Finland',
        'FJ'=>'Fiji',
        'FK'=>'Falkland Islands (Malvinas)',
        'FM'=>'Micronesia, Federated States of',
        'FO'=>'Faroe Islands',
        'FR'=>'France',
        'GA'=>'Gabon',
        'GB'=>'United Kingdom',
        'GD'=>'Grenada',
        'GE'=>'Georgia',
        'GF'=>'French Guiana',
        'GG'=>'Guernsey',
        'GH'=>'Ghana',
        'GI'=>'Gibraltar',
        'GL'=>'Greenland',
        'GM'=>'Gambia',
        'GN'=>'Guinea',
        'GP'=>'Guadeloupe',
        'GQ'=>'Equatorial Guinea',
        'GR'=>'Greece',
        'GS'=>'South Georgia and the South Sandwich Islands',
        'GT'=>'Guatemala',
        'GU'=>'Guam',
        'GW'=>'Guinea-Bissau',
        'GY'=>'Guyana',
        'HK'=>'Hong Kong',
        'HM'=>'Heard Island and McDonald Islands',
        'HN'=>'Honduras',
        'HR'=>'Croatia',
        'HT'=>'Haiti',
        'HU'=>'Hungary',
        'ID'=>'Indonesia',
        'IE'=>'Ireland',
        'IL'=>'Israel',
        'IM'=>'Isle of Man',
        'IN'=>'India',
        'IO'=>'British Indian Ocean Territory',
        'IQ'=>'Iraq',
        'IR'=>'Iran, Islamic Republic of',
        'IS'=>'Iceland',
        'IT'=>'Italy',
        'JE'=>'Jersey',
        'JM'=>'Jamaica',
        'JO'=>'Jordan',
        'JP'=>'Japan',
        'KE'=>'Kenya',
        'KG'=>'Kyrgyzstan',
        'KH'=>'Cambodia',
        'KI'=>'Kiribati',
        'KM'=>'Comoros',
        'KN'=>"Saint Kitts and Nevis",
        'KP'=>"Korea, Democratic People's Republic of",
        'KR'=>'Korea, Republic of',
        'KW'=>'Kuwait',
        'KY'=>'Cayman Islands',
        'KZ'=>'Kazakhstan',
        'LA'=>"Lao People's Democratic Republic",
        'LB'=>'Lebanon',
        'LC'=>'Saint Lucia',
        'LI'=>'Liechtenstein',
        'LK'=>'Sri Lanka',
        'LR'=>'Liberia',
        'LS'=>'Lesotho',
        'LT'=>'Lithuania',
        'LU'=>'Luxembourg',
        'LV'=>'Latvia',
        'LY'=>'Libya',
        'MA'=>'Morocco',
        'MC'=>'Monaco',
        'MD'=>'Moldova, Republic of',
        'ME'=>'Montenegro',
        'MF'=>'Saint Martin (French part)',
        'MG'=>'Madagascar',
        'MH'=>'Marshall Islands',
        'MK'=>'Macedonia, the former Yugoslav Republic of',
        'ML'=>'Mali',
        'MM'=>'Myanmar',
        'MN'=>'Mongolia',
        'MO'=>'Macao',
        'MP'=>'Northern Mariana Islands',
        'MQ'=>'Martinique',
        'MR'=>'Mauritania',
        'MS'=>'Montserrat',
        'MT'=>'Malta',
        'MU'=>'Mauritius',
        'MV'=>'Maldives',
        'MW'=>'Malawi',
        'MX'=>'Mexico',
        'MY'=>'Malaysia',
        'MZ'=>'Mozambique',
        'NA'=>'Namibia',
        'NC'=>'New Caledonia',
        'NE'=>'Niger',
        'NF'=>'Norfolk Island',
        'NG'=>'Nigeria',
        'NI'=>'Nicaragua',
        'NL'=>'Netherlands',
        'NO'=>'Norway',
        'NP'=>'Nepal',
        'NR'=>'Nauru',
        'NU'=>'Niue',
        'NZ'=>'New Zealand',
        'OM'=>'Oman',
        'PA'=>'Panama',
        'PE'=>'Peru',
        'PF'=>'French Polynesia',
        'PG'=>'Papua New Guinea',
        'PH'=>'Philippines',
        'PK'=>'Pakistan',
        'PL'=>'Poland',
        'PM'=>'Saint Pierre and Miquelon',
        'PN'=>'Pitcairn',
        'PR'=>'Puerto Rico',
        'PS'=>'Palestine, State of',
        'PT'=>'Portugal',
        'PW'=>'Palau',
        'PY'=>'Paraguay',
        'QA'=>'Qatar',
        'RE'=>'Reunion',
        'RO'=>'Romania',
        'RS'=>'Serbia',
        'RU'=>'Russian Federation',
        'RW'=>'Rwanda',
        'SA'=>'Saudi Arabia',
        'SB'=>'Solomon Islands',
        'SC'=>'Seychelles',
        'SD'=>'Sudan',
        'SE'=>'Sweden',
        'SG'=>'Singapore',
        'SH'=>'Saint Helena, Ascension and Tristan da Cunha',
        'SI'=>'Slovenia',
        'SJ'=>'Svalbard and Jan Mayen',
        'SK'=>'Slovakia',
        'SL'=>'Sierra Leone',
        'SM'=>'San Marino',
        'SN'=>'Senegal',
        'SO'=>'Somalia',
        'SR'=>'Suriname',
        'SS'=>'South Sudan',
        'ST'=>'Sao Tome and Principe',
        'SV'=>'El Salvador',
        'SX'=>'Sint Maarten (Dutch part)',
        'SY'=>'Syrian Arab Republic',
        'SZ'=>'Swaziland',
        'TC'=>'Turks and Caicos Islands',
        'TD'=>'Chad',
        'TF'=>'French Southern Territories',
        'TG'=>'Togo',
        'TH'=>'Thailand',
        'TJ'=>'Tajikistan',
        'TK'=>'Tokelau',
        'TL'=>'Timor-Leste',
        'TM'=>'Turkmenistan',
        'TN'=>'Tunisia',
        'TO'=>'Tonga',
        'TR'=>'Turkey',
        'TT'=>'Trinidad and Tobago',
        'TV'=>'Tuvalu',
        'TW'=>'Taiwan, Province of China',
        'TZ'=>'Tanzania, United Republic of',
        'UA'=>'Ukraine',
        'UG'=>'Uganda',
        'UM'=>'United States Minor Outlying Islands',
        'US'=>'United States',
        'UY'=>'Uruguay',
        'UZ'=>'Uzbekistan',
        'VA'=>'Holy See (Vatican City State)',
        'VC'=>'Saint Vincent and the Grenadines',
        'VE'=>'Venezuela, Bolivarian Republic of',
        'VG'=>'Virgin Islands, British',
        'VI'=>'Virgin Islands, U.S.',
        'VN'=>'Viet Nam',
        'VU'=>'Vanuatu',
        'WF'=>'Wallis and Futuna',
        'WS'=>'Samoa',
        'YE'=>'Yemen',
        'YT'=>'Mayotte',
        'ZA'=>'South Africa',
        'ZM'=>'Zambia',
        'ZW'=>'Zimbabwe',
        'YU'=>'Yugoslavia*',
        'CS'=>'Serbia and Montenegro*',
        'AN'=>'Netherlands Antilles*',
        'AA'=>'Reserved IP addresses*',
        'EU'=>'Europe*',
        'AP'=>'Asia/Pacific Region*'];

        $this->assign('countries', $countries);
        $this->assign('page', '/storage/admin/src/page/settings_country.tpl');
    }

    public function postCountry(){
        if(!isset($_POST['token']) OR $_POST['token'] <> \Session::get('token')) {
            exit(header('Location: /admin/dashboard/'));
        }

        unset($_POST['token']);
        $data = [];
        foreach ($_POST as $k=>$v) {
            if($v<>'' AND (float) $v<>1 AND (float) $v>=0){
                $data[(string) $k] = sprintf ("%.2f", (float) $v);
            }
        }
        Settings::update('country_rules', json_encode($data));
        exit(header('Location: /admin/settings/country/'));
    }

    public function getAds(){
        $this->assign('ads', Blocks::get());
        $this->assign('page', '/storage/admin/src/page/ads_add.tpl');
    }

    public function postAds(){
        if(!isset($_POST['token']) OR $_POST['token'] <> \Session::get('token')) {
            exit(header('Location: /admin/dashboard/'));
        }
        unset($_POST['token']);

        foreach ($_POST as $k=>$v) {
            Blocks::updateByPage($k, $v);
            CacheManager::delete('block_'.$k);
        }
        exit(header('Location: /admin/ads/add/'));
    }


    public function getBan() {
        $this->assign('page', '/storage/admin/src/page/ban_add.tpl');
    }

    public function postBan() {
        if(!isset($_POST['token']) OR $_POST['token'] <> \Session::get('token')) {
            exit(header('Location: /admin/dashboard/'));
        }

        foreach (explode("\n", $_POST['bans']) as $v){
            if(!Bans::getByData(trim($v))){
                Bans::insert(['b_data'=>trim($v)]);
            }
        }
        exit(header('Location: /admin/ban/list/1/'));
    }

    public function getBanList($args) {

        $page_per = 15;
        $page_count = ceil(Bans::count()/$page_per);
        $page_cur = $args['page'];

        $this->assign('twbsPagination', ['count'=>$page_count, 'cur'=>$page_cur]);
        $this->assign('bans', Bans::getPerPage($page_cur, $page_per));

        $this->assign('page', '/storage/admin/src/page/ban_list.tpl');
    }

    public function postBanList($args){
        if(!isset($_POST['token']) OR $_POST['token'] <> \Session::get('token')) {
            exit(header('Location: /admin/dashboard/'));
        }

        Bans::deleteById($_POST['unban']);
        exit(header('Location: /admin/ban/list/'.$args['page'].'/'));
    }

    public function getPaymentsList($args){
        $page_per = 15;
        $page_count = ceil(Payments::count()/$page_per);
        $page_cur = $args['page'];

        $this->assign('twbsPagination', ['count'=>$page_count, 'cur'=>$page_cur]);
        $this->assign('payments', Payments::getPerPage($page_cur, $page_per));

        $this->assign('page', '/storage/admin/src/page/payments_list.tpl');
    }

    public function getActionsList($args){
        $page_per = 15;
        $page_count = ceil(Actions::count()/$page_per);
        $page_cur = $args['page'];

        $this->assign('twbsPagination', ['count'=>$page_count, 'cur'=>$page_cur]);
        $this->assign('actions', Actions::getPerPage($page_cur, $page_per));

        $this->assign('page', '/storage/admin/src/page/actions_list.tpl');
    }

    public function getExit(){
       \Session::destroy();
        exit(header('Location: /'));
    }

}