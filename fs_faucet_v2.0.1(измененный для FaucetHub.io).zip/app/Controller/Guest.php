<?php

/* Bitcoin faucet
 * http://faucetsystem.com/
 * Copyright (c) 2017 FaucetSystem.com
 *
 * Email: faucetsystem@gmail.com
 * ToxID: 77755759350B68121FED9377DFF1D4030793DBA9A23EED849E6369CF880E277297915137F7AB
 */

namespace Controller;

use Model\Actions;
use Model\Bans;
use Model\Blocks;
use Model\Jackpot;
use Model\Payments;
use Model\Settings;
use Module\Faucetsystem;
use Module\Ip;
use Module\Lc;
use Module\Render;
use Module\Secure;
use Module\Solvemedia;
use phpFastCache\CacheManager;
use ReCaptcha\ReCaptcha;

class Guest extends Render {

    public $access = 'guest, admin';

    public function getClaimFirst($args){

        \Session::set('timer', time());

        if(isset($args['referral'])) {
            \Session::set('referral', $args['referral']);
        }

        if(is_null(CacheManager::get('block_first'))) {
            foreach (Blocks::getByPage('first') as $v) {
                $ads[$v->block_name] = $v->block_content;
            }
            CacheManager::set('block_first', $ads, 60*60);
        }

        if(is_null(CacheManager::get('faucetsystem'))) {
            $faucetsystem = new Faucetsystem($this->settings['faucetsystem_apikey']);
            CacheManager::set('faucetsystem', $faucetsystem->getBalance(), 5*60);
        }

        if(is_null(CacheManager::get('wins'))) {
            CacheManager::set('wins', Payments::getRecentWins(), 5*60);
        }



        $this->assign('wins', CacheManager::get('wins')                   );
        $this->assign('ad'  , CacheManager::get('block_first')            );
        $this->assign('fs'  , CacheManager::get('faucetsystem'  )            );
        $this->assign('faucetsystem_error', CacheManager::get('faucetsystem_error'));
        $this->assign('page', 'template/'.$this->settings['system_template'].'/src/page/claim_first.tpl');
    }

    public function postClaimSecond(){

        if(isset($_POST['address']) AND trim($_POST['address'])<>''){
            \Session::set('address', trim($_POST['address']));
            setcookie('address', trim($_POST['address']), time()+60*60*24*365, '/');
        }else{
            Actions::insert(['a_type'=>'invalid:address']);
            $toastr['error'][] = 'Address error!';
        }

        if($this->settings['recaptcha_status']){
            if(isset($_POST['g-recaptcha-response'])){
                $resp = (new ReCaptcha($this->settings['recaptcha_secretkey']))->verify($_POST['g-recaptcha-response'], $_SERVER['REMOTE_ADDR']);
                if(!$resp->isSuccess()){
                    Actions::insert(['a_type'=>'invalid:recaptcha']);
                    $toastr['error'][] = 'Captcha error!';
                }
            }else{
                $toastr['error'][] = 'Captcha error!';
                Actions::insert(['a_type'=>'bot:recaptcha']);
            }
        }

        if($this->settings['solvemedia_status']){
            if(isset($_POST['adcopy_challenge']) AND $_POST['adcopy_challenge']) {
                $solvemedia = new Solvemedia();
                $solvemedia_valid = $solvemedia->solvemedia_check_answer($this->settings['solvemedia_vkey'], $_SERVER['REMOTE_ADDR'], $_POST['adcopy_challenge'], $_POST['adcopy_response'], $this->settings['solvemedia_hkey']);
                if(!$solvemedia_valid){
                    $toastr['error'][] = 'Captcha error!';
                    Actions::insert(['a_type'=>'invalid:solvemedia']);
                }
            }else{
                $toastr['error'][] = 'Captcha error!';
                Actions::insert(['a_type'=>'bot:solvemedia']);
            }
        }

        if(time()-\Session::get('timer') < $this->settings['timer_first'] OR \Session::get('timer') == null) {
            Actions::insert(['a_type'=>'bot:timer']);
            $toastr['error'][] = 'Timer error!';
        }

        \Session::set('timer', time());

        if(isset($toastr)){
            \Session::set('toastr', $toastr);
            exit(header('Location: /'));
        }

        \Session::set('step', 'one');

        if($this->settings['os_lc']) {
            $lc = Lc::generate();
            \Session::set('lc'  , $lc['answer']  );
            $this->assign('lc_q', $lc['question']);
            $this->assign('lc_a', $lc['vars']    );
        }

        if(is_null(CacheManager::get('block_second'))) {
            foreach (Blocks::getByPage('second') as $v) {
                $ads[$v->block_name] = $v->block_content;
            }
            CacheManager::set('block_second', $ads, 60*60);
        }
        $this->assign('ad', CacheManager::get('block_second'));

        $this->assign('page', 'template/'.$this->settings['system_template'].'/src/page/claim_second.tpl');
    }

    public function postClaimThird(){

        if(Bans::getByData(Ip::get()) OR Bans::getByData(\Session::get('address'))){
            $toastr['error'][] = 'You are banned from this faucet!';
        }

        $last_payment = Payments::getByIP(Ip::get());
        if(isset($last_payment) AND (time() - $last_payment->p_time) < ($this->settings['timer_global']*60)){
            $toastr['error'][] = 'Please try again after '.ceil($this->settings['timer_global']-((time() - $last_payment->p_time)/60)).' minutes!';
        }

        $last_payment = Payments::getByAddress(\Session::get('address'));
        if(isset($last_payment) AND (time() - $last_payment->p_time) < ($this->settings['timer_global']*60)){
            $toastr['error'][] = 'Please try again after '.ceil($this->settings['timer_global']-((time() - $last_payment->p_time)/60)).' minutes!';
        }

        if(\Session::get('step')!='one'){
            $toastr['error'][] = 'Session error!';
        }
        \Session::delete('step');

        if($this->settings['os_lc']) {
            if(isset($_POST['secret'])){
                if($_POST['secret'] != \Session::get('lc')){
                    Actions::insert(['a_type'=>'invalid:lc']);
                    $toastr['error'][] = 'Captcha error!';
                }
            }else{
                Actions::insert(['a_type'=>'bot:lc']);
                $toastr['error'][] = 'Captcha error!';
            }
        }

        \Session::set('lc', md5(Secure::getRandomString(10)));

        //bb
       if(isset($toastr)){
           \Session::set('toastr', $toastr);
           exit(header('Location: /'));
       }

        $ticket = mt_rand(1,10000);
        foreach(json_decode($this->settings['money_reward'], true) as $win=>$v){
            $ticket -= $v*100;
            if($ticket<=0) break;
        }

        $jackpot = false;
        if($this->settings['jackpot_status']){
            if(mt_rand(1, $this->settings['jackpot_chance']) == $this->settings['jackpot_chance']){
                $jackpot = true;
                $win = $this->settings['jackpot_amount'];
                Jackpot::insert(['j_address'=>\Session::get('address'),'j_amount'=>$win,'j_time'=>time()]);
                Settings::update('jackpot_amount', 0);
            }
        }
        //$win


        $rules = json_decode($this->settings['country_rules'], true);
        $cc = \TabGeo\country(Ip::get());
        if(isset($rules[$cc])){
            $win = ceil($win * (float) $rules[$cc]);
        }


        //bb
        if(isset($toastr)){
            \Session::set('toastr', $toastr);
            exit(header('Location: /'));
        }

        if($jackpot==false){
            Settings::jackpot(ceil($win*($this->settings['jackpot_rate']/100)));
        }

        $faucetsystem = new Faucetsystem($this->settings['faucetsystem_apikey']);

        $p_id = 0;
        $response['success'] = false;
        if($win>=1 AND \Session::get('address')){
            $response = $faucetsystem->send(\Session::get('address'), $win, 'false', Ip::get());
            if($response['success']==false){
                if(!strpos($response['message'], 'address')) {
                    CacheManager::set('faucetsystem_error', $response['message'], 60*5);
                }
            }else{
                CacheManager::delete('faucetsystem_error');
                $p_id = Payments::insert(['p_address'=>\Session::get('address'), 'p_amount'=>$win, 'p_referral'=>0]);
                setcookie('timer_global', time(), time()+60*60*24*365, '/');
            }
        }

        if(\Session::get('referral') AND $this->settings['referral_status'] AND $win>=1 AND \Session::get('address')<>\Session::get('referral') AND $response['success']){
            $referral = ceil($win*($this->settings['referral_commission']/100));
            $response_ref = $faucetsystem->send(\Session::get('referral'), $referral, 'true', Ip::get());
            if($response_ref['success']==true) {
                Payments::insert(['p_address' => \Session::get('referral'), 'p_amount' => $referral, 'p_referral' => $p_id]);
            }
        }

        $this->assign('response', $response);

        if(is_null(CacheManager::get('block_third'))) {
            foreach (Blocks::getByPage('third') as $v) {
                $ads[$v->block_name] = $v->block_content;
            }
            CacheManager::set('block_third', $ads, 60*60);
        }
        $this->assign('ad', CacheManager::get('block_third'));

        $this->assign('page', 'template/'.$this->settings['system_template'].'/src/page/claim_third.tpl');
    }

    public function getLogin(){
        if(!is_null(CacheManager::get('login_attempts'))){
            $this->assign('error', 'Bruteforce detected.<br>Login page blocked.');
        }
        $this->assign('page', 'template/'.$this->settings['system_template'].'/src/page/login.tpl');
    }

    public function postLogin(){
        if($this->settings['admin_login'] == $_POST['admin_login'] AND $this->settings['admin_password'] == $_POST['admin_password'] AND is_null(CacheManager::get('login_attempts'))){
            \Session::set('admin', 1);
            \Session::set('token', md5(time().Ip::get()));
            exit(header('Location: /admin/dashboard/'));
        }
        CacheManager::set('login_attempts', 1, $this->settings['lag_bruteforce']);
        exit(header('Location: /guest/login/'));
    }

    public function getCc(){
        $cc = json_decode($this->settings['country_rules'], true);
        arsort($cc);
        $this->assign('cc', $cc);
        $this->assign('page', 'template/'.$this->settings['system_template'].'/src/page/cc.tpl');
    }

    public function getJackpot(){

        $this->assign('jackpots', Jackpot::get());
        $this->assign('page', 'template/'.$this->settings['system_template'].'/src/page/jackpot.tpl');
    }
}