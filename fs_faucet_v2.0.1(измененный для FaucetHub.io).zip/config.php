<?php

/* Bitcoin faucet
 * http://faucetsystem.com/
 * Copyright (c) 2017 FaucetSystem.com
 *
 * Email: faucetsystem@gmail.com
 * ToxID: 77755759350B68121FED9377DFF1D4030793DBA9A23EED849E6369CF880E277297915137F7AB
 */

define('MYSQL_SERVER'  , 'localhost');//MySQL server
define('MYSQL_LOGIN'   , 'root2');//MySQL login
define('MYSQL_PASSWORD', 'root_paww');//MySQL password
define('MYSQL_BASE'    , 'faucet');//MySQL base