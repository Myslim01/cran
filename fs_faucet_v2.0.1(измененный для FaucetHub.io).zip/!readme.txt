1) Create a MySQL database.
2) Import a SQL dump (!dump.sql in archive) file to mysql (you can use phpMyAdmin to import a SQL dump file into your MySQL database).
3) Edit config.php (you can open and edit it using a plain text editor program like Notepad).
4) Upload all files from the directory to your server's public directory.
5) To grant the Apache web server write permissions for the "tmp" directory.
6) Open your website and go to Admin Zone (defaul login: admin, default password: admin).